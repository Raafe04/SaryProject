package bookinghotel.PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HotelListPage {

	WebDriver driver;
	
	public HotelListPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;	
	}
	
	 By resultpage = By.xpath("//*[@id='breadcrumb']/ol/li[5]/a/div");
	 By hotelrating = By.xpath("//div[@id='hotellist_inner']/div[2]/div[2]/div[1]/div[2]/div/div/a/div/div[1]");
	 By hotelname = By.xpath("//div[@id='hotellist_inner']/div[2]/div[2]/div[1]/div[1]/div[1]/h3/a/span[1]");
	 By price = By.xpath("//div[@id='hotellist_inner']/div[2]/div[2]/div[3]/div/div/div/div/div[2]/div[1]/div[2]/div/div/span");
	 By image = By.xpath("//*[@id='hotellist_inner']/div[2]/div/a/img");
	 
	 
	 
	 public WebElement resultpage() {
		   
		   return driver.findElement(resultpage);
	   }
	 public WebElement rating() {
		   
		   return driver.findElement(hotelrating);
	   }
	 
	 public WebElement hotelname() {
		   
		   return driver.findElement(hotelname);
	   }
	 public WebElement price() {
		   
		   return driver.findElement(price);
	   }
	 
	 public WebElement image() {
		   
		   return driver.findElement(image);
	   }
	 
	 
}
