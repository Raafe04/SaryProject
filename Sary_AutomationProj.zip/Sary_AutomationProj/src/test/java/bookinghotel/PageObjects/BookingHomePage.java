package bookinghotel.PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import bookinghotel.Sary_AutomationProj.BaseClass;

public class BookingHomePage {
	
	
	WebDriver driver;
	
	String enddat =BaseClass.strDate2;

	public BookingHomePage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;	
	}
	
   By destination = By.cssSelector("input#ss") ;
   By dateinput = By.cssSelector("span.sb-date-field__icon.sb-date-field__icon-btn.bk-svg-wrapper.calendar-restructure-sb") ;
   By startdate = By.cssSelector("td.bui-calendar__date.bui-calendar__date--today") ;
   By enddate = By.cssSelector("td[data-date = "+enddat+"]");
   By search = By.cssSelector("button.sb-searchbox__button") ;
	
   
   
   public WebElement destination() {
	   
	   return driver.findElement(destination);
   }
   
  public WebElement dateinput() {
	   
	   return driver.findElement(dateinput);
   }

  public WebElement startdate() {
	   
	   return driver.findElement(startdate);
  }
  
  public WebElement enddate() {
	   
	   return driver.findElement(enddate);
  }
  
  public WebElement search() {
	   
	   return driver.findElement(search);
 }
  

}
