package bookinghotel.Sary_AutomationProj;

import static org.testng.Assert.assertTrue;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import bookinghotel.PageObjects.BookingHomePage;
import bookinghotel.PageObjects.HotelListPage;

public class BookingHotelTest extends BaseClass {
	
	BookingHomePage launchpage;
	HotelListPage  hotellistpage;
	
	@Test
	@Parameters({"browser","destination"})
	public void test1_AssertreturnPage(String browser,String destination)
	{
		
	    launchpage = new BookingHomePage(driver);
	    launchpage.destination().clear();
	    launchpage.destination().sendKeys(destination);
	    launchpage.dateinput().click();	
	    launchpage.startdate().click();
	    launchpage.enddate().click();
	    launchpage.search().click();
	    hotellistpage = new HotelListPage(driver);
	    String resultpage = hotellistpage.resultpage().getText();
	    if(resultpage.contentEquals("Search results")) {
       	Assert.assertTrue(true);
       	System.out.println("testinside-----------------------"+resultpage);
        }
        else {
       	 
       	 Assert.assertTrue(false);
        } 
	}
	
	@Test
	@Parameters({"browser","destination"})
	public void test2_Asserthotelrating(String browser,String destination)
	{
	    launchpage = new BookingHomePage(driver);
	    launchpage.destination().clear();
	    launchpage.destination().sendKeys(destination);
	    launchpage.dateinput().click();
	    launchpage.startdate().click();
	    launchpage.enddate().click();
	    launchpage.search().click();
	    hotellistpage = new HotelListPage(driver);
	    String rating = hotellistpage.rating().getText();
	    System.out.println("test------------------------"+rating);
        Float i = Float.valueOf(rating).floatValue(); 
         if(i>=7.0) {
        	 
            Assert.assertTrue(true);
          }
         else {
        	 
             Assert.assertTrue(false);
          }
	
	}

	@Test
	@Parameters({"browser","destination"})
	public void test3_gethotelgetprice(String browser,String destination) {
		
		launchpage = new BookingHomePage(driver);
	    launchpage.destination().clear();
	    launchpage.destination().sendKeys(destination);
	    launchpage.dateinput().click();
	    launchpage.startdate().click();
	    launchpage.enddate().click();
	    launchpage.search().click();
	    hotellistpage = new HotelListPage(driver);
	    String hotelname = hotellistpage.hotelname().getText();
        System.out.println("hotelname------------------------"+hotelname);
	    String price = hotellistpage.price().getText();
	    System.out.println("price------------------------"+price);
	   
	}
          
	
	@Test
	@Parameters({"browser","destination"})
	public void test4_AssertPicdisplayed(String browser,String destination) {
		
		launchpage = new BookingHomePage(driver);
	    launchpage.destination().clear();
	    launchpage.destination().sendKeys(destination);
	    launchpage.dateinput().click();
	    launchpage.startdate().click();
	    launchpage.enddate().click();
	    launchpage.search().click();
	    hotellistpage = new HotelListPage(driver);
        WebElement image=hotellistpage.image() ;
	    boolean imagePresent = image.isDisplayed();
	    System.out.println("image------------------------"+imagePresent);
	    Assert.assertTrue(imagePresent,"No image is exist" );
	    
	   
	}
	
	
	@Test
	@Parameters({"browser","destination"})
	public void test5_Assertnavigatedtocorrectpage(String browser,String destination) {
		launchpage = new BookingHomePage(driver);
	    launchpage.destination().clear();
	    launchpage.destination().sendKeys(destination);
	    launchpage.dateinput().click();
	    launchpage.startdate().click();
	    launchpage.enddate().click();
	    launchpage.search().click();
	    hotellistpage = new HotelListPage(driver);
		String hotelname = hotellistpage.hotelname().getText();
		hotellistpage.hotelname().click();
		String page = driver.getPageSource();
		if(page.contains(hotelname)) {
		    Assert.assertTrue(true);
		    System.out.println("testinside2-----------------------"+hotelname);
		    }
		    else {
		       	 
		       Assert.assertTrue(false);
		      }
	    
	   
	}
	



}
