package bookinghotel.Sary_AutomationProj;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

public class BaseClass {
	
	public static WebDriver driver;
	
	
	public static String url = "https://www.booking.com";
	  static DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");  
	  static LocalDateTime now = LocalDateTime.now();  
	  static String strDate =  dtf.format(now); 
	  static String strDate1= LocalDate.parse(strDate).plusDays(1).toString();
	  public static String strDate2 = "'"+strDate1+"'";
	  
	  
	
	@BeforeClass
	@Parameters("browser")
	public void setup(String browser) throws Exception{
	//Check if parameter passed from TestNG is 'firefox'
		
	if(browser.equalsIgnoreCase("Firefox")){
	//create firefox instance
	System.setProperty("webdriver.gecko.driver",System.getProperty("user.dir")+"//Drivers//geckodriver.exe");
	driver = new FirefoxDriver();
	}
	//Check if parameter passed as 'chrome'
	else if (browser.equalsIgnoreCase("Chrome")){
	//set path to chromedriver.exe
	System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"//Drivers//chromedriver.exe");
	driver = new ChromeDriver();
	}
	
	
	
	
	}
	
	
	@AfterClass
	public void TearDown() {
		
		driver.quit();
		
	}
	
	
	@BeforeMethod
	public void start() throws Exception {
	driver.get(url);
	driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	}
	   

}
